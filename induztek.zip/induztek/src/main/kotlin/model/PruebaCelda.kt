// Archivo: model/PruebaCelda.kt
// Responsabilidad: representa una prueba de tensión soportada sobre una celda de media tensión

package model

import java.time.LocalDateTime

// PruebaCelda extiende Prueba con su propio criterio: tensión soportada respecto a la nominal
class PruebaCelda(
    codigo: String,
    equipoId: String,
    instalacionCliente: String,
    fechaHora: LocalDateTime,
    val tensionNominalKV: Double // propiedad adicional exclusiva de PruebaCelda: tensión nominal de diseño
) : Prueba(codigo, equipoId, instalacionCliente, fechaHora, TipoEquipo.CELDA_MT) {

    companion object {
        const val FACTOR_APROBADO = 1.0   // ≥ 100% de la tensión nominal: soporta correctamente
        const val FACTOR_OBSERVADO = 0.9  // 90%–100%: al límite, requiere seguimiento
        // < 90% de la tensión nominal: rechazado, riesgo de falla dieléctrica
    }

    override fun evaluarResultado(valorMedido: Double): ResultadoPrueba {
        val proporcion = valorMedido / tensionNominalKV // qué fracción de la tensión nominal soportó
        return when {
            proporcion >= FACTOR_APROBADO -> ResultadoPrueba.APROBADO
            proporcion >= FACTOR_OBSERVADO -> ResultadoPrueba.OBSERVADO
            else -> ResultadoPrueba.RECHAZADO
        }
    }

    override fun unidadMedida(): String = "kV" // tensión soportada en kilovolts

    override fun descripcionTipo(): String = "Celda MT — Tensión soportada (nominal ${tensionNominalKV} kV)"
}
