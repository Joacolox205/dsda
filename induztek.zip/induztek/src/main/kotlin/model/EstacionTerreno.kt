// Archivo: model/EstacionTerreno.kt
// Responsabilidad: representa un "cupo" de trabajo en terreno (un técnico/dispositivo móvil
// que puede estar atendiendo una prueba a la vez). Es el equivalente conceptual al "Puesto"
// del ejemplo de referencia, pero aplicado a técnicos en terreno en vez de butacas de cine

package model

import state.EstadoProtocolo // importamos la sealed class que define los estados posibles

// class mutable: el estado de la estación cambia durante la operación del sistema
class EstacionTerreno(
    val numero: Int // número identificador de la estación (técnico/dispositivo); no cambia una vez asignado
) {
    // var: el estado puede cambiar en cualquier momento (Libre → EnProceso → RegistradoEnTerreno, etc.)
    var estado: EstadoProtocolo = EstadoProtocolo.Libre

    // referencia a la prueba actualmente asociada; null cuando la estación está libre
    var pruebaAsignada: Prueba? = null

    // propiedad calculada: retorna true solo si la estación está en estado Libre
    val estaLibre: Boolean get() = estado is EstadoProtocolo.Libre

    // propiedad calculada: retorna true si la estación tiene una prueba registrada en terreno
    // (pendiente de formalizar), análogo a "estaOcupado" en el ejemplo
    val tieneRegistroPendiente: Boolean get() = estado is EstadoProtocolo.RegistradoEnTerreno

    // función que asocia una prueba a la estación y cambia su estado a RegistradoEnTerreno
    fun asignarPrueba(prueba: Prueba) {
        pruebaAsignada = prueba // guardamos la referencia a la prueba
        estado = EstadoProtocolo.RegistradoEnTerreno(prueba.equipoId) // estado pasa a "registrado en terreno"
    }

    // función que libera la estación: elimina la prueba asignada y vuelve al estado Libre
    fun liberar() {
        pruebaAsignada = null              // eliminamos la referencia a la prueba anterior
        estado = EstadoProtocolo.Libre     // la estación queda disponible para una nueva prueba
    }

    // función que cambia el estado sin modificar la prueba asignada (útil para EnProceso)
    fun cambiarEstado(nuevoEstado: EstadoProtocolo) {
        estado = nuevoEstado // asignamos directamente el nuevo estado a la estación
    }

    // función que muestra en pantalla el estado actual de la estación (usada en reportes)
    fun mostrarEstado() {
        val descripcionEstado = when (val e = estado) { // when con smart cast sobre el tipo de estado
            is EstadoProtocolo.Libre -> "LIBRE"
            is EstadoProtocolo.RegistradoEnTerreno -> "REGISTRADO EN TERRENO — equipo ${e.equipoId}"
            is EstadoProtocolo.EnProceso -> "EN PROCESO — ${e.motivo}"
            is EstadoProtocolo.Formalizado -> "FORMALIZADO — equipo ${e.equipoId} (${e.resultado})"
        }
        println("Estación #$numero: $descripcionEstado") // imprime número y estado en una línea
    }
}
