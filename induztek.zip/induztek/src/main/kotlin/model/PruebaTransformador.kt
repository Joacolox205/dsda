// Archivo: model/PruebaTransformador.kt
// Responsabilidad: representa una prueba de resistencia de aislación sobre un transformador

package model

import java.time.LocalDateTime

// PruebaTransformador hereda de Prueba y es una subclase concreta (se puede instanciar)
class PruebaTransformador(
    codigo: String,               // código de protocolo, se pasa al constructor de Prueba
    equipoId: String,             // identificador del transformador
    instalacionCliente: String,   // instalación del cliente
    fechaHora: LocalDateTime      // fecha y hora de la prueba
) : Prueba(codigo, equipoId, instalacionCliente, fechaHora, TipoEquipo.TRANSFORMADOR) {

    // companion object: contiene los umbrales propios de este tipo de prueba
    companion object {
        const val UMBRAL_APROBADO = 100.0  // ≥ 100 MΩ: aislación en muy buen estado
        const val UMBRAL_OBSERVADO = 50.0  // 50–100 MΩ: aceptable pero a seguimiento
        // < 50 MΩ: rechazado, riesgo de falla de aislación
    }

    // override: implementación concreta del método abstracto de la clase padre
    override fun evaluarResultado(valorMedido: Double): ResultadoPrueba = when {
        valorMedido >= UMBRAL_APROBADO -> ResultadoPrueba.APROBADO
        valorMedido >= UMBRAL_OBSERVADO -> ResultadoPrueba.OBSERVADO
        else -> ResultadoPrueba.RECHAZADO
    }

    override fun unidadMedida(): String = "MΩ" // resistencia de aislación en megaohms

    override fun descripcionTipo(): String = "Transformador — Resistencia de aislación"
}
