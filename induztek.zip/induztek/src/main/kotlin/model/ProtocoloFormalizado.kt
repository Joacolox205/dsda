// Archivo: model/ProtocoloFormalizado.kt
// Responsabilidad: representa el protocolo formal emitido al finalizar la evaluación
// de una prueba eléctrica. Es el documento de respaldo que el caso pide entregar
// al cliente ("el respaldo que certifica qué se probó y con qué resultado")

package model

import java.time.LocalDateTime

// data class: Kotlin genera automáticamente equals(), hashCode() y toString() útiles
data class ProtocoloFormalizado(
    val numero: Int,                     // número correlativo del protocolo dentro del turno
    val prueba: Prueba,                  // referencia a la prueba que generó este protocolo
    val valorMedido: Double,             // valor efectivamente medido en terreno
    val resultado: ResultadoPrueba,      // resultado de comparar el valor contra el rango del equipo
    val fechaFormalizacion: LocalDateTime // momento en que el protocolo quedó formalizado
) {
    // función que formatea el protocolo como texto para mostrar en pantalla
    fun mostrar() {
        println("========== PROTOCOLO #$numero ==========")
        println("Tipo de prueba    : ${prueba.descripcionTipo()}")
        println("Código protocolo  : ${prueba.codigo}")
        println("Equipo            : ${prueba.equipoId}")
        println("Instalación       : ${prueba.instalacionCliente}")
        println("Valor medido      : $valorMedido ${prueba.unidadMedida()}")
        println("Resultado         : $resultado")
        println("Formalizado       : $fechaFormalizacion")
        println("==========================================")
    }
}
