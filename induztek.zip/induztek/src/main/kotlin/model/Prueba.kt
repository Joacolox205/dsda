// Archivo: model/Prueba.kt
// Responsabilidad: clase abstracta que representa una prueba eléctrica genérica
// realizada en terreno sobre un equipo del cliente (transformador, relé, celda, etc.)
// Esta clase define los datos y comportamientos comunes a todos los tipos de prueba

package model

import java.time.LocalDateTime // usamos LocalDateTime para registrar el momento exacto de la prueba

// abstract class: no se puede instanciar directamente; obliga a las subclases a implementar
// evaluarResultado(), igual que Sala obligaba a implementar calcularCobro()
abstract class Prueba(
    val codigo: String,                 // código único del protocolo (formato: dos letras, dos dígitos, dos letras)
    val equipoId: String,               // identificador del equipo físico probado, ej: "TRF-014"
    val instalacionCliente: String,     // instalación/ubicación del cliente donde se realiza la prueba
    val fechaHora: LocalDateTime,       // momento exacto en que se realiza la prueba en terreno
    val tipoEquipo: TipoEquipo          // tipo de equipo: TRANSFORMADOR, RELE_PROTECCION o CELDA_MT
) {

    // companion object: agrupa constantes y funciones de clase (similares a static en Java)
    companion object {
        // Regex para validar el formato del código: exactamente 2 letras + 2 dígitos + 2 letras
        // (mismo formato usado en el ejemplo de referencia, para mantener consistencia)
        val FORMATO_CODIGO = Regex("^[A-Za-z]{2}[0-9]{2}[A-Za-z]{2}$")

        // función de clase que valida si un código tiene el formato correcto
        fun codigoValido(codigo: String): Boolean = FORMATO_CODIGO.matches(codigo)
    }

    // abstract fun: obliga a cada subclase a definir su propio criterio de evaluación
    // recibe el valor medido en terreno y retorna si la prueba fue aprobada, observada o rechazada
    abstract fun evaluarResultado(valorMedido: Double): ResultadoPrueba

    // abstract fun: cada subclase retorna la unidad de medida de su valor (MΩ, ms, kV)
    abstract fun unidadMedida(): String

    // función que retorna una descripción legible del tipo de prueba (usada en reportes)
    abstract fun descripcionTipo(): String
}
