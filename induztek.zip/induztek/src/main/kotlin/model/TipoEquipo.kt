// Archivo: model/TipoEquipo.kt
// Responsabilidad: define los tipos de equipos eléctricos primarios/secundarios
// que Induztek prueba en terreno (transformadores, relés, celdas, cables)

package model

// enum class: tipo enumerado que limita los valores posibles a exactamente tres opciones
// (según el caso: "transformadores, relés de protección, celdas, cables, entre otros";
// se modelan 3 para mantener el ejercicio acotado, igual que TipoCliente en el ejemplo)
enum class TipoEquipo {
    TRANSFORMADOR,      // equipo primario; se prueba resistencia de aislación (MΩ)
    RELE_PROTECCION,    // equipo secundario; se prueba tiempo de disparo (ms)
    CELDA_MT            // celda de media tensión; se prueba tensión soportada (kV)
}
