// Archivo: model/ResultadoPrueba.kt
// Responsabilidad: define los posibles resultados al evaluar el valor medido
// de una prueba eléctrica contra el rango aceptable de su tipo de equipo

package model

// enum class: resultado de comparar el valor medido contra los umbrales del equipo
enum class ResultadoPrueba {
    APROBADO,   // el valor medido está dentro del rango óptimo
    OBSERVADO,  // el valor medido está en un rango límite; requiere seguimiento
    RECHAZADO   // el valor medido está fuera de norma; el equipo no pasa la prueba
}
