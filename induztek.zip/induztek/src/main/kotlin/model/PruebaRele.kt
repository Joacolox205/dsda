// Archivo: model/PruebaRele.kt
// Responsabilidad: representa una prueba de tiempo de disparo sobre un relé de protección

package model

import java.time.LocalDateTime

// PruebaRele extiende Prueba; a diferencia del transformador, aquí un valor MENOR es mejor
class PruebaRele(
    codigo: String,
    equipoId: String,
    instalacionCliente: String,
    fechaHora: LocalDateTime
) : Prueba(codigo, equipoId, instalacionCliente, fechaHora, TipoEquipo.RELE_PROTECCION) {

    companion object {
        const val UMBRAL_APROBADO = 50.0   // ≤ 50 ms: disparo dentro del tiempo de coordinación
        const val UMBRAL_OBSERVADO = 80.0  // 50–80 ms: lento, requiere calibración/seguimiento
        // > 80 ms: rechazado, riesgo de descoordinación de protecciones
    }

    override fun evaluarResultado(valorMedido: Double): ResultadoPrueba = when {
        valorMedido <= UMBRAL_APROBADO -> ResultadoPrueba.APROBADO
        valorMedido <= UMBRAL_OBSERVADO -> ResultadoPrueba.OBSERVADO
        else -> ResultadoPrueba.RECHAZADO
    }

    override fun unidadMedida(): String = "ms" // tiempo de disparo en milisegundos

    override fun descripcionTipo(): String = "Relé de protección — Tiempo de disparo"
}
