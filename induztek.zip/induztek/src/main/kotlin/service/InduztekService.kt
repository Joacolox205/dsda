// Archivo: service/InduztekService.kt
// Responsabilidad: lógica central del sistema; gestiona estaciones de terreno,
// registro y formalización de protocolos, y las consultas de negocio del caso

package service

import kotlinx.coroutines.delay  // delay() suspende la corrutina sin bloquear el hilo
import model.*                    // importamos todos los modelos del paquete model
import state.EstadoProtocolo      // importamos los estados de la estación
import java.time.LocalDateTime

// class: clase concreta que contiene toda la lógica de negocio de Induztek
class InduztekService(
    private val nombreEmpresa: String, // nombre de la empresa, se muestra en reportes y mensajes
    private val capacidad: Int         // número de estaciones de terreno (técnicos) operando en paralelo
) {
    // MutableList de estaciones; se inicializa con 'capacidad' estaciones numeradas del 1 al N
    private val estaciones: MutableList<EstacionTerreno> = MutableList(capacidad) { EstacionTerreno(it + 1) }

    // historial general de protocolos formalizados durante el turno
    private val historial: MutableList<ProtocoloFormalizado> = mutableListOf()

    // R.3.2 — historial por equipo: permite comparar el estado actual de un equipo
    // con sus mediciones históricas, tal como pide el punto 2.4 del caso
    private val historialPorEquipo: MutableMap<String, MutableList<ProtocoloFormalizado>> = mutableMapOf()

    // contador correlativo de protocolos; incrementa con cada formalización exitosa
    private var contadorProtocolos = 0

    // mapa que acumula cuántos protocolos hay por resultado (APROBADO, OBSERVADO, RECHAZADO)
    private val conteoPorResultado: MutableMap<ResultadoPrueba, Int> = mutableMapOf()


    // R3 — Validación de formato del código del protocolo


    // delega la validación al companion object de Prueba; retorna true si el formato es correcto
    private fun validarCodigo(codigo: String): Boolean = Prueba.codigoValido(codigo)


    // R5 — Registro asíncrono de una prueba en terreno
    // (suspend = solo puede llamarse desde una corrutina; simula la conectividad
    // limitada/inestable en terreno mencionada en el punto 3.3 del caso)


    suspend fun registrarPruebaEnTerreno(prueba: Prueba) { // suspend: puede pausarse sin bloquear

        // VALIDACIÓN R3/R6: el código debe tener el formato correcto antes de continuar
        if (!validarCodigo(prueba.codigo)) {
            println("[ERROR] Código inválido '${prueba.codigo}'. Formato requerido: AA00AA.")
            return // salimos sin registrar; el sistema sigue funcionando normalmente
        }

        // buscamos la primera estación libre disponible en la lista
        val estacion = estaciones.firstOrNull { it.estaLibre }

        // R6: si no hay estaciones libres, avisamos y no realizamos el registro
        if (estacion == null) {
            println("[ERROR] Sin capacidad: todas las estaciones de terreno están ocupadas.")
            return // salimos sin bloquear el sistema
        }

        // paso 1: marcamos la estación como EnProceso mientras se sincroniza el registro
        estacion.cambiarEstado(EstadoProtocolo.EnProceso("Registrando en terreno: equipo ${prueba.equipoId}"))
        println("[INFO] Estación #${estacion.numero} → registrando prueba de '${prueba.equipoId}' en terreno...")

        delay(3_000) // simulamos 3 segundos de conectividad limitada/inestable en terreno (punto 3.3)

        // paso 2: confirmado el registro, asociamos la prueba y la estación queda con registro pendiente
        estacion.asignarPrueba(prueba)
        println("[OK]   Estación #${estacion.numero} → prueba registrada en terreno: ${prueba.equipoId} (${prueba.codigo})")
    }


    // R5 — Formalización asíncrona del protocolo
    // (simula el momento en que el técnico regresa a un computador/tiene conectividad
    // y el protocolo pasa de "registrado en terreno" a "formalizado")


    suspend fun formalizarProtocolo(codigo: String, valorMedido: Double) {

        // buscamos la estación que tiene el registro pendiente con el código indicado
        val estacion = estaciones.firstOrNull {
            it.tieneRegistroPendiente && it.pruebaAsignada?.codigo == codigo
        }

        // R6: si no encontramos el protocolo, avisamos y continuamos
        if (estacion == null) {
            println("[ERROR] Protocolo '$codigo' no encontrado en ninguna estación con registro pendiente.")
            return
        }

        val prueba = estacion.pruebaAsignada!! // seguro aquí porque ya verificamos que no es null

        // paso 1: marcamos la estación como EnProceso mientras se formaliza el protocolo
        estacion.cambiarEstado(EstadoProtocolo.EnProceso("Formalizando protocolo de ${prueba.equipoId}"))
        println("[INFO] Estación #${estacion.numero} → formalizando protocolo de '${prueba.equipoId}'...")

        delay(6_500) // simulamos 6,5 segundos de sincronización/formalización del protocolo

        // paso 2: evaluamos el resultado y emitimos el protocolo formal
        val protocolo = emitirProtocolo(prueba, valorMedido)

        // paso 3: liberamos la estación independientemente del resultado
        estacion.liberar()

        if (protocolo != null) {
            println("[OK]   Estación #${estacion.numero} → protocolo #${protocolo.numero} formalizado (${protocolo.resultado}).")
            mostrarComparacionHistorica(prueba.equipoId) // R 2.4: comparar con mediciones anteriores
        }
    }


    // R3 — Evaluar resultado y emitir protocolo (llamado internamente desde formalizarProtocolo)


    private fun emitirProtocolo(prueba: Prueba, valorMedido: Double): ProtocoloFormalizado? {
        if (valorMedido < 0.0) { // R3/R6: un valor medido negativo no es válido físicamente
            println("[ERROR] Valor medido inválido ($valorMedido) para el protocolo '${prueba.codigo}'. No se emite.")
            return null // retornamos null para indicar fallo; el programa no se detiene
        }

        val resultado = prueba.evaluarResultado(valorMedido) // R3: cálculo polimórfico según el tipo de equipo

        contadorProtocolos++ // incrementamos el número correlativo
        val protocolo = ProtocoloFormalizado(
            numero = contadorProtocolos,
            prueba = prueba,
            valorMedido = valorMedido,
            resultado = resultado,
            fechaFormalizacion = LocalDateTime.now()
        )

        historial.add(protocolo) // agregamos el protocolo al historial general del turno

        // agregamos el protocolo al historial específico de ese equipo (para comparación futura)
        val listaEquipo = historialPorEquipo.getOrPut(prueba.equipoId) { mutableListOf() }
        listaEquipo.add(protocolo)

        // actualizamos el conteo por resultado
        conteoPorResultado[resultado] = (conteoPorResultado[resultado] ?: 0) + 1

        protocolo.mostrar() // mostramos el protocolo en pantalla
        return protocolo
    }

    // función auxiliar que compara el protocolo recién emitido con la medición anterior del mismo
    // equipo, si existe — responde directamente al punto 2.4 del caso ("comparar el estado actual
    // de un equipo con sus mediciones históricas")
    private fun mostrarComparacionHistorica(equipoId: String) {
        val registros = historialPorEquipo[equipoId] ?: return
        if (registros.size < 2) return // no hay medición anterior con la cual comparar

        val actual = registros.last()
        val anterior = registros[registros.size - 2]
        val delta = actual.valorMedido - anterior.valorMedido
        println(
            "[INFO] Comparación histórica equipo '$equipoId': " +
            "${anterior.valorMedido} → ${actual.valorMedido} ${actual.prueba.unidadMedida()} " +
            "(Δ ${"%.2f".format(delta)})"
        )
    }


    // R4 — Consultas de negocio


    // ¿Cuántas estaciones de terreno están disponibles ahora mismo?
    fun estacionesDisponibles(): Int = estaciones.count { it.estaLibre }

    // R 3.2 — Historial de pruebas anteriores del mismo equipo, para fines de comparación
    fun historialDeEquipo(equipoId: String): List<ProtocoloFormalizado> =
        historialPorEquipo[equipoId]?.toList() ?: emptyList()

    // ¿Qué protocolos obtuvieron un resultado específico (APROBADO, OBSERVADO, RECHAZADO)?
    fun protocolosPorResultado(resultado: ResultadoPrueba): List<ProtocoloFormalizado> =
        historial.filter { it.resultado == resultado }

    // ¿Cuál es la tasa de aprobación del turno?
    fun tasaAprobacion(): Double =
        if (historial.isEmpty()) 0.0
        else historial.count { it.resultado == ResultadoPrueba.APROBADO }.toDouble() / historial.size

    // ¿Cuáles son todos los códigos de protocolos formalizados en el turno?
    fun codigosProtocolosFormalizados(): List<String> = historial.map { it.prueba.codigo }

    // ¿Qué equipo tiene más pruebas registradas en su historial?
    fun equipoConMasPruebas(): Map.Entry<String, MutableList<ProtocoloFormalizado>>? =
        historialPorEquipo.maxByOrNull { it.value.size }


    // R4 — Reporte de cierre de turno


    fun generarReporteCierre() {
        println("\n******************************************")
        println("*     REPORTE DE CIERRE DE TURNO           *")
        println("*     $nombreEmpresa")
        println("********************************************")

        if (historial.isEmpty()) {
            println("No se formalizó ningún protocolo en este turno.")
            return
        }

        println("\n── Detalle por protocolo formalizado ──")
        historial.forEach { protocolo ->
            println(
                "Protocolo #${protocolo.numero} | ${protocolo.prueba.descripcionTipo()} | " +
                "Código: ${protocolo.prueba.codigo} | Equipo: ${protocolo.prueba.equipoId} | " +
                "${protocolo.valorMedido} ${protocolo.prueba.unidadMedida()} | ${protocolo.resultado}"
            )
        }

        println("\n── Resumen del turno ──")
        println("Protocolos formalizados : ${historial.size}")
        println("Tasa de aprobación      : ${"%.0f".format(tasaAprobacion() * 100)}%")
        println("Aprobados / Observados / Rechazados : " +
            "${conteoPorResultado[ResultadoPrueba.APROBADO] ?: 0} / " +
            "${conteoPorResultado[ResultadoPrueba.OBSERVADO] ?: 0} / " +
            "${conteoPorResultado[ResultadoPrueba.RECHAZADO] ?: 0}")
        println("Estaciones libres cierre: ${estacionesDisponibles()} de $capacidad")
        println("****************************************\n")
    }
}
