package org.induztek

// Archivo: Main.kt
// Responsabilidad: punto de entrada del programa; demuestra el funcionamiento completo del sistema
// Este archivo crea los objetos, registra pruebas en terreno/formalizaciones y llama las consultas de negocio

import kotlinx.coroutines.runBlocking // runBlocking: permite llamar funciones suspend desde main()
import model.*                         // importamos todos los modelos del paquete model
import service.InduztekService         // importamos el servicio principal del negocio
import java.time.LocalDateTime         // usamos LocalDateTime para registrar el momento de cada prueba

// fun main: función de entrada principal del programa
// runBlocking crea un scope de corrutinas que bloquea el hilo principal hasta que todo termine
fun main() = runBlocking {

    // creamos el servicio con el nombre de la empresa y la cantidad de estaciones de terreno
    val induztek = InduztekService("Induztek Ingeniería SpA", 3)

    println("==============================================")
    println("   Sistema de Protocolos Induztek Ingeniería  ")
    println("==============================================\n")

    // ─────────────────────────────────────────────
    // R6 — Prueba de código con formato inválido
    // El sistema debe rechazarlo con mensaje claro y continuar funcionando
    // ─────────────────────────────────────────────
    println("=== Prueba de código inválido ===")
    val pruebaInvalida = PruebaTransformador(
        codigo = "123ABC",              // formato incorrecto: empieza con dígitos
        equipoId = "TRF-000",
        instalacionCliente = "Subestación Norte",
        fechaHora = LocalDateTime.now()
    )
    induztek.registrarPruebaEnTerreno(pruebaInvalida) // debe mostrar [ERROR] y no registrar nada
    println()


    // R5 — Registro de pruebas en terreno (operación asíncrona — tarda 3 seg cada una)

    println("=== Registrando pruebas en terreno ===")

    // Transformador TRF-014, primera medición del turno
    val p1 = PruebaTransformador(
        codigo = "TR01SN",
        equipoId = "TRF-014",
        instalacionCliente = "Subestación Norte",
        fechaHora = LocalDateTime.now()
    )

    // Relé de protección RP-002
    val p2 = PruebaRele(
        codigo = "RP02SN",
        equipoId = "RP-002",
        instalacionCliente = "Subestación Norte",
        fechaHora = LocalDateTime.now()
    )

    // Celda de media tensión CMT-007, tensión nominal de diseño 24 kV
    val p3 = PruebaCelda(
        codigo = "CM03SP",
        equipoId = "CMT-007",
        instalacionCliente = "Planta Sur",
        fechaHora = LocalDateTime.now(),
        tensionNominalKV = 24.0
    )

    // Transformador TRF-014, segunda visita al mismo equipo (permite comparar histórico)
    val p4 = PruebaTransformador(
        codigo = "TR04SN",
        equipoId = "TRF-014",
        instalacionCliente = "Subestación Norte",
        fechaHora = LocalDateTime.now()
    )

    // registramos cada prueba de forma secuencial (cada una espera 3 seg en terreno)
    induztek.registrarPruebaEnTerreno(p1)
    induztek.registrarPruebaEnTerreno(p2)
    induztek.registrarPruebaEnTerreno(p3)
    induztek.registrarPruebaEnTerreno(p4)
    println()

    // ─────────────────────────────────────────────
    // R4 — Consulta: ¿cuántas estaciones de terreno quedan libres?
    // ─────────────────────────────────────────────
    println("Estaciones disponibles ahora: ${induztek.estacionesDisponibles()} de 3\n")

    // ─────────────────────────────────────────────
    // R5 — Formalización de protocolos (operación asíncrona — tarda 6,5 seg cada una)
    // Internamente: evalúa el resultado, emite el protocolo, libera la estación
    // ─────────────────────────────────────────────
    println("=== Formalizando protocolos ===")

    // p1: Transformador, 120 MΩ → ≥ 100 → APROBADO
    induztek.formalizarProtocolo("TR01SN", 120.0)

    // p2: Relé, 65 ms → entre 50 y 80 → OBSERVADO
    induztek.formalizarProtocolo("RP02SN", 65.0)

    // p3: Celda, 21 kV sobre nominal 24 kV → 87,5% → RECHAZADO
    induztek.formalizarProtocolo("CM03SP", 21.0)

    // p4: Transformador TRF-014, 40 MΩ → RECHAZADO (además dispara la comparación con p1: 120 → 40 MΩ)
    induztek.formalizarProtocolo("TR04SN", 40.0)


    // R6 — Prueba: formalización de un código que no existe

    println("\n=== Prueba de código no encontrado ===")
    induztek.formalizarProtocolo("XX00XX", 10.0) // código que no tiene registro pendiente
    println()


    // R4 — Consultas de negocio adicionales

    println("=== Consultas de negocio ===")

    // ¿qué protocolos fueron RECHAZADOS en el turno?
    val rechazados = induztek.protocolosPorResultado(ResultadoPrueba.RECHAZADO)
    println("Protocolos rechazados: ${rechazados.map { it.prueba.equipoId }}")

    // ¿cuál es la tasa de aprobación del turno?
    println("Tasa de aprobación: ${"%.0f".format(induztek.tasaAprobacion() * 100)}%")

    // ¿cuáles son todos los códigos de protocolos formalizados en el turno?
    println("Códigos formalizados: ${induztek.codigosProtocolosFormalizados()}")

    // ¿historial completo del equipo TRF-014? (para comparar su evolución en el tiempo)
    val historialTrf = induztek.historialDeEquipo("TRF-014")
    println("Historial TRF-014: ${historialTrf.map { "${it.valorMedido} MΩ (${it.resultado})" }}")

    // ¿qué equipo tiene más pruebas registradas?
    val masProbado = induztek.equipoConMasPruebas()
    println("Equipo con más pruebas: ${masProbado?.key ?: "N/A"} — ${masProbado?.value?.size ?: 0} protocolo(s)")
    println()

    // ─────────────────────────────────────────────
    // R4 — Reporte de cierre de turno
    // ─────────────────────────────────────────────
    induztek.generarReporteCierre()
}
