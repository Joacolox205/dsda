// Archivo: state/EstadoProtocolo.kt
// Responsabilidad: define los posibles estados de un protocolo de prueba eléctrica
// Modela directamente el requerimiento 3.2 del caso: "estado del protocolo
// (por ejemplo, registrado en terreno / formalizado)"

package state

// Importamos la librería de corrutinas para usar delay() en el servicio
// sealed class: solo las subclases definidas dentro de este archivo pueden extenderla
// Esto garantiza que el sistema solo maneje estados válidos y conocidos
sealed class EstadoProtocolo {

    // Objeto singleton que representa una estación libre, sin ninguna prueba asociada
    object Libre : EstadoProtocolo()

    // data class: representa una prueba registrada en terreno, aún no formalizada
    // guarda el id del equipo probado, tal como pide el caso (3.2)
    data class RegistradoEnTerreno(val equipoId: String) : EstadoProtocolo()

    // data class: representa un protocolo en proceso (registrando o formalizando)
    data class EnProceso(val motivo: String) : EstadoProtocolo()

    // data class: representa un protocolo ya formalizado, con su resultado final
    data class Formalizado(val equipoId: String, val resultado: String) : EstadoProtocolo()
}
